// Shared hooks for countdown + telemetry
const { useState, useEffect, useRef, useCallback, useMemo } = React;

// ── Countdown ──────────────────────────────────────────
window.useCountdown = function useCountdown(initial = 600, speedMultiplier = 1) {
  const [remaining, setRemaining] = useState(initial);
  const [isHolding, setIsHolding] = useState(false);
  const holdRef = useRef(false);
  const speedRef = useRef(speedMultiplier);

  useEffect(() => { holdRef.current = isHolding; }, [isHolding]);
  useEffect(() => { speedRef.current = speedMultiplier; }, [speedMultiplier]);

  useEffect(() => {
    let acc = 0;
    let last = performance.now();
    const id = setInterval(() => {
      const now = performance.now();
      const dt = (now - last) / 1000;
      last = now;
      if (holdRef.current) return;
      acc += dt * speedRef.current;
      if (acc >= 1) {
        const ticks = Math.floor(acc);
        acc -= ticks;
        setRemaining(r => Math.max(0, r - ticks));
      }
    }, 100);
    return () => clearInterval(id);
  }, []);

  const hold = useCallback(() => setIsHolding(true), []);
  const resume = useCallback(() => setIsHolding(false), []);
  const reset = useCallback(() => { setRemaining(initial); setIsHolding(false); }, [initial]);

  return { remaining, isHolding, isComplete: remaining <= 0, hold, resume, reset, setRemaining };
};

// ── Telemetry ──────────────────────────────────────────
const HISTORY_LENGTH = 24;

function initTelemetry() {
  const state = {};
  Object.entries(window.SUBSYSTEM_CONFIG).forEach(([key, config]) => {
    const metrics = {};
    const history = {};
    config.metrics.forEach(m => {
      metrics[m.key] = m.base;
      history[m.key] = Array(HISTORY_LENGTH).fill(m.base);
    });
    state[key] = { status: 'nominal', metrics, history };
  });
  return state;
}

function nextValue(metric, key, remaining) {
  let base = metric.base;
  if (key === 'AVIONICS' && metric.key === 'bayTemp' && remaining <= 270 && remaining > 120) {
    base = metric.base + 2.3;
  }
  const delta = (Math.random() - 0.5) * metric.variance * 2;
  return parseFloat((base + delta).toFixed(metric.decimals ?? 1));
}

window.useTelemetry = function useTelemetry(isHolding, remaining) {
  const [telemetry, setTelemetry] = useState(initTelemetry);
  const isHoldingRef = useRef(isHolding);
  const remainingRef = useRef(remaining);

  useEffect(() => { isHoldingRef.current = isHolding; }, [isHolding]);
  useEffect(() => { remainingRef.current = remaining; }, [remaining]);

  useEffect(() => {
    const interval = setInterval(() => {
      if (isHoldingRef.current) return;
      const rem = remainingRef.current;
      setTelemetry(prev => {
        const next = {};
        Object.entries(window.SUBSYSTEM_CONFIG).forEach(([key, config]) => {
          const metrics = {};
          const history = {};
          config.metrics.forEach(m => {
            const val = nextValue(m, key, rem);
            metrics[m.key] = val;
            history[m.key] = [...(prev[key].history[m.key].slice(1)), val];
          });
          let status = 'nominal';
          if (key === 'AVIONICS' && rem <= 270 && rem > 120) status = 'warning';
          next[key] = { status, metrics, history };
        });
        return next;
      });
    }, 1500);
    return () => clearInterval(interval);
  }, []);

  return telemetry;
};

// ── ARIA timeline driver ────────────────────────────────
// Emits messages from ARIA_TIMELINE + confirmation messages from approvals
window.useAriaChannel = function useAriaChannel(remaining, isHolding) {
  const [messages, setMessages] = useState([]);
  const triggeredRef = useRef(new Set());

  // Seed first message immediately
  useEffect(() => {
    const first = window.ARIA_TIMELINE[0];
    if (first && !triggeredRef.current.has(first.id)) {
      triggeredRef.current.add(first.id);
      setMessages([{ ...first, timestamp: Date.now() }]);
    }
  }, []);

  useEffect(() => {
    if (isHolding) return;
    window.ARIA_TIMELINE.forEach(msg => {
      if (remaining <= msg.triggerAt && !triggeredRef.current.has(msg.id)) {
        triggeredRef.current.add(msg.id);
        setMessages(prev => [...prev, { ...msg, timestamp: Date.now() }]);
      }
    });
  }, [remaining, isHolding]);

  const push = useCallback((msg) => {
    setMessages(prev => [...prev, { ...msg, timestamp: Date.now() }]);
  }, []);

  return { messages, push };
};

// ── Approval queue state ────────────────────────────────
window.useApprovalQueue = function useApprovalQueue(remaining, pushAria) {
  const [approved, setApproved] = useState(() => new Set());
  const [log, setLog] = useState([]);

  const triggered = useMemo(
    () => window.AUTONOMOUS_STEPS.filter(s => remaining <= s.triggerAt),
    [remaining]
  );
  const pending = useMemo(
    () => triggered.find(s => !approved.has(s.id)),
    [triggered, approved]
  );

  const approve = useCallback((step) => {
    setApproved(prev => new Set([...prev, step.id]));
    setLog(prev => [...prev, { ...step, ts: Date.now() }]);
    pushAria({
      id: `confirm-${step.id}`,
      text: `AUTHORIZED — ${step.action}. ${step.confirm}`,
      type: 'success',
      system: step.system,
    });
  }, [pushAria]);

  return { approved, log, pending, approve, total: window.AUTONOMOUS_STEPS.length };
};

// ── Utilities ───────────────────────────────────────────
window.formatCountdown = function(seconds) {
  if (seconds <= 0) return 'T+00:00';
  const m = Math.floor(seconds / 60).toString().padStart(2, '0');
  const s = (seconds % 60).toString().padStart(2, '0');
  return `T-${m}:${s}`;
};

window.formatTime = function(ts) {
  return new Date(ts).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

window.generateAriaReply = function(raw, telemetry) {
  const q = raw.toLowerCase().trim();
  if (q === 'status' || q === 'report') {
    const lines = window.SUBSYSTEM_ORDER.map(key => {
      const sub = telemetry[key];
      const cfg = window.SUBSYSTEM_CONFIG[key];
      const p = cfg.metrics[0];
      return `  ${cfg.label.padEnd(16)} ${sub.status.toUpperCase().padEnd(8)} ${p.label}: ${sub.metrics[p.key]}${p.unit}`;
    });
    return `SYSTEM STATUS REPORT\n${lines.join('\n')}\n\nAll links nominal.`;
  }
  if (q === 'hold') return 'No active hold conditions. Count proceeding nominally.';
  if (q.startsWith('explain ')) {
    const name = q.replace('explain ', '').trim().toUpperCase();
    const key = Object.keys(window.SUBSYSTEM_EXPLANATIONS).find(k => k.includes(name.replace(' ', '_')));
    return key ? window.SUBSYSTEM_EXPLANATIONS[key] : 'Unknown subsystem. Try: propulsion, avionics, ground support, range safety, power, comms.';
  }
  if (q === 'help' || q === '?') {
    return 'Available commands:\n  status       — full system report\n  hold         — hold status\n  explain X    — subsystem detail\n  abort        — sim abort';
  }
  if (q === 'abort') return 'ABORT noted. In live ops this initiates safe shutdown. Use HOLD to pause the sim.';
  return "Monitoring all systems. No action required. Type 'status' for a full report, or 'explain [subsystem]' for detail.";
};
