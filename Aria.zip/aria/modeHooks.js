// Mode-specific hooks: FSAE telemetry + generic timeline/radio drivers
const { useState: _useState, useEffect: _useEffect, useRef: _useRef, useCallback: _useCallback, useMemo: _useMemo } = React;

// ── FSAE telemetry (ported from hooks/useFsaeTelemetry.js) ──
function fsaeJitter(base, range) { return base + (Math.random() - 0.5) * range * 2; }
function fsaeFmt(v, decimals) { return parseFloat(v.toFixed(decimals)); }

function initFsae() {
  return {
    POWERTRAIN: { status: 'nominal', metrics: { rpm: 3200, throttle: 0, waterTemp: 65.1, oilPress: 3.8 }, history: { rpm: Array(24).fill(3200) } },
    AERO:       { status: 'nominal', metrics: { frontDF: 2, rearDF: 3, rideHeightF: 32.0, rideHeightR: 28.5 }, history: { frontDF: Array(24).fill(2) } },
    SUSPENSION: { status: 'nominal', metrics: { rollAngle: 0.2, flTravel: 12.4, frTravel: 11.8, tireTemp: 42 }, history: { rollAngle: Array(24).fill(0.2) } },
    DAQ:        { status: 'nominal', metrics: { dataRate: 100, canLoad: 42, gpsLock: 12, storage: 8420 }, history: { dataRate: Array(24).fill(100) } },
    DRIVER:     { status: 'nominal', metrics: { gLat: 0.02, gLon: 0.01, steer: 0, brakePres: 0.0 }, history: { gLat: Array(24).fill(0.02) } },
    RACE_CONTROL: { status: 'nominal', metrics: { lapNum: 0, lapTime: 0.00, bestLap: 0.00, fuelLevel: 100 }, history: { fuelLevel: Array(24).fill(100) } },
  };
}

window.useFsaeTelemetry = function useFsaeTelemetry(isHolding, remaining) {
  const [telemetry, setTelemetry] = _useState(initFsae);
  const isHoldingRef = _useRef(isHolding);
  const remainingRef = _useRef(remaining);
  _useEffect(() => { isHoldingRef.current = isHolding; }, [isHolding]);
  _useEffect(() => { remainingRef.current = remaining; }, [remaining]);

  _useEffect(() => {
    const t = setInterval(() => {
      if (isHoldingRef.current) return;
      const r = remainingRef.current;
      setTelemetry(prev => {
        const warmupDone = r < 195;
        const targetTemp = warmupDone
          ? fsaeFmt(fsaeJitter(87, 1.5), 1)
          : fsaeFmt(65 + (300 - r) * 0.115, 1);
        const targetRpm = warmupDone
          ? (Math.random() > 0.82 ? Math.round(fsaeJitter(4200, 400)) : 3200)
          : Math.round(3200 + (300 - r) * 2.5);
        const clampedRpm = Math.min(targetRpm, 4800);
        const throttle = warmupDone && Math.random() > 0.85 ? Math.round(Math.random() * 35) : 0;
        const pwStatus = targetTemp > 95 ? 'warning' : 'nominal';
        const tireBase = 42 + (300 - r) * 0.04;
        const roll = fsaeFmt(Math.abs(fsaeJitter(0.1, 0.12)), 1);
        const gL = fsaeFmt(Math.abs(fsaeJitter(0.01, 0.025)), 2);
        const gN = fsaeFmt(Math.abs(fsaeJitter(0.01, 0.02)), 2);

        return {
          POWERTRAIN: {
            status: pwStatus,
            metrics: { rpm: clampedRpm, throttle, waterTemp: Math.min(targetTemp, 92), oilPress: fsaeFmt(fsaeJitter(3.85, 0.08), 1) },
            history: { rpm: [...prev.POWERTRAIN.history.rpm.slice(1), clampedRpm] },
          },
          AERO: {
            status: 'nominal',
            metrics: { frontDF: Math.round(fsaeJitter(2, 2)), rearDF: Math.round(fsaeJitter(3, 2)), rideHeightF: fsaeFmt(fsaeJitter(32.0, 0.25), 1), rideHeightR: fsaeFmt(fsaeJitter(28.5, 0.25), 1) },
            history: { frontDF: [...prev.AERO.history.frontDF.slice(1), 2] },
          },
          SUSPENSION: {
            status: 'nominal',
            metrics: { rollAngle: roll, flTravel: fsaeFmt(fsaeJitter(12.4, 0.4), 1), frTravel: fsaeFmt(fsaeJitter(11.8, 0.4), 1), tireTemp: Math.round(fsaeJitter(tireBase, 0.5)) },
            history: { rollAngle: [...prev.SUSPENSION.history.rollAngle.slice(1), roll] },
          },
          DAQ: {
            status: 'nominal',
            metrics: { dataRate: 100, canLoad: Math.round(fsaeJitter(42, 3)), gpsLock: 12, storage: Math.max(0, Math.round(prev.DAQ.metrics.storage - 0.6)) },
            history: { dataRate: [...prev.DAQ.history.dataRate.slice(1), 100] },
          },
          DRIVER: {
            status: 'nominal',
            metrics: { gLat: gL, gLon: gN, steer: Math.round(fsaeJitter(0, 1.5)), brakePres: fsaeFmt(Math.max(0, fsaeJitter(0, 0.04)), 1) },
            history: { gLat: [...prev.DRIVER.history.gLat.slice(1), gL] },
          },
          RACE_CONTROL: {
            status: 'nominal',
            metrics: { ...prev.RACE_CONTROL.metrics, fuelLevel: 100 },
            history: { fuelLevel: [...prev.RACE_CONTROL.history.fuelLevel.slice(1), 100] },
          },
        };
      });
    }, 1500);
    return () => clearInterval(t);
  }, []);

  return telemetry;
};

// ── Generic ARIA-channel driver (timeline-based) ──
// Emits scheduled messages from a timeline and exposes push() for inline events
window.useAriaChannelFor = function useAriaChannelFor(timeline, remaining, isHolding) {
  const [messages, setMessages] = _useState([]);
  const triggeredRef = _useRef(new Set());
  const timelineRef = _useRef(timeline);

  // Reset messages when timeline changes (mode switch)
  _useEffect(() => {
    timelineRef.current = timeline;
    triggeredRef.current = new Set();
    const first = timeline[0];
    if (first) {
      triggeredRef.current.add(first.id);
      setMessages([{ ...first, timestamp: Date.now() }]);
    } else {
      setMessages([]);
    }
  }, [timeline]);

  _useEffect(() => {
    if (isHolding) return;
    timelineRef.current.forEach(msg => {
      if (remaining <= msg.triggerAt && !triggeredRef.current.has(msg.id)) {
        triggeredRef.current.add(msg.id);
        setMessages(prev => [...prev, { ...msg, timestamp: Date.now() }]);
      }
    });
  }, [remaining, isHolding]);

  const push = _useCallback((msg) => {
    setMessages(prev => [...prev, { ...msg, timestamp: Date.now() }]);
  }, []);

  const reset = _useCallback(() => {
    triggeredRef.current = new Set();
    setMessages([]);
  }, []);

  return { messages, push, reset };
};

// ── Radio chatter log (triggered by countdown) ──
window.useRadio = function useRadio(radioTimeline, remaining, isHolding, colorMap = {}) {
  const [entries, setEntries] = _useState([]);
  const triggeredRef = _useRef(new Set());
  const timelineRef = _useRef(radioTimeline);

  _useEffect(() => {
    timelineRef.current = radioTimeline;
    triggeredRef.current = new Set();
    setEntries([]);
  }, [radioTimeline]);

  _useEffect(() => {
    if (isHolding) return;
    timelineRef.current.forEach(rc => {
      if (remaining <= rc.triggerAt && !triggeredRef.current.has(rc.id)) {
        triggeredRef.current.add(rc.id);
        const color = rc.color || colorMap[rc.from] || '#B8A9FA';
        setEntries(prev => [...prev, { ...rc, color, timestamp: Date.now(), at: rc.triggerAt }]);
      }
    });
  }, [remaining, isHolding]);

  return entries;
};

// ── FSAE checklist state (auto vs manual acknowledge) ──
window.useChecklist = function useChecklist(items, remaining, isHolding, pushAria) {
  const [done, setDone] = _useState(() => new Set());

  // Auto-tick "auto" items when their trigger passes
  _useEffect(() => {
    if (isHolding) return;
    items.forEach(it => {
      if (remaining <= it.triggerAt && it.type === 'auto' && !done.has(it.id)) {
        setDone(prev => new Set([...prev, it.id]));
      }
    });
  }, [remaining, isHolding, items]);

  const ack = _useCallback((item) => {
    setDone(prev => new Set([...prev, item.id]));
    if (pushAria) {
      pushAria({ id: `ack-${item.id}`, text: `CONFIRMED — ${item.name}`, type: 'success' });
    }
  }, [pushAria]);

  const reset = _useCallback(() => setDone(new Set()), []);

  return { done, ack, reset };
};
