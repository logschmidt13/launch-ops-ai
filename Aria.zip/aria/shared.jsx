// Shared UI components — TopBar, SubsystemGrid, ApprovalQueue
const { useState: uS, useEffect: uE, useRef: uR, useMemo: uM } = React;

// ── Sparkline ──────────────────────────────────────────
function Sparkline({ data, color, width = 96, height = 26, fill = true }) {
  if (!data || data.length < 2) return null;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 0.001;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const polyline = pts.join(' ');
  const area = fill ? `M0,${height} L${pts.join(' L')} L${width},${height} Z` : null;
  return (
    <svg width={width} height={height} className="spark" style={{ display: 'block' }}>
      {fill && <path d={area} fill={color} opacity="0.12" />}
      <polyline points={polyline} fill="none" stroke={color} strokeWidth="1.4" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}
window.Sparkline = Sparkline;

// ── Subsystem Card ─────────────────────────────────────
const STATUS_HEX = { nominal: '#00C97A', warning: '#FFB300', critical: '#FF2D2D' };

function SubsystemCard({ id, data, compact, systemConfig, highlight }) {
  const [expanded, setExpanded] = uS(false);
  const cfgMap = systemConfig || window.SUBSYSTEM_CONFIG;
  const config = cfgMap[id];
  if (!config || !data) return null;
  const { status, metrics, history } = data;
  const dot = STATUS_HEX[status];
  const displayMetrics = expanded ? config.metrics : config.metrics.slice(0, 2);
  const primary = config.metrics.find(m => m.key === config.primaryMetric);

  return (
    <div className={`sub-card ${status !== 'nominal' ? `sub-card--${status}` : ''} ${expanded ? 'sub-card--expanded' : ''} ${highlight ? 'sub-card--highlight' : ''}`}
         onClick={() => setExpanded(e => !e)}
         style={highlight ? { borderColor: highlight } : undefined}>
      <div className="sub-card__head">
        <div className="sub-card__title-row">
          <span className="dot" style={{ background: dot, boxShadow: `0 0 6px ${dot}` }} />
          <span className="sub-card__label">{config.label}</span>
        </div>
        <span className="sub-card__status" style={{ color: dot }}>{status.toUpperCase()}</span>
      </div>
      <div className="sub-card__primary">
        <span className="sub-card__primary-val" style={{ color: status !== 'nominal' ? dot : '#F0F2F8' }}>
          {metrics[primary.key]}<span className="sub-card__primary-unit">{primary.unit}</span>
        </span>
        <Sparkline data={history[primary.key]} color={dot} width={compact ? 70 : 96} height={22} />
      </div>
      {!compact && (
        <div className="sub-card__metrics">
          {displayMetrics.slice(1).map(m => (
            <div key={m.key} className="mrow">
              <span className="mrow__label">{m.label}</span>
              <span className="mrow__val">{metrics[m.key]}{m.unit}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
window.SubsystemCard = SubsystemCard;

// ── Subsystem Grid ─────────────────────────────────────
function SubsystemGrid({ telemetry, compact, systemConfig, systemOrder, highlightRole, title }) {
  const cfgMap = systemConfig || window.SUBSYSTEM_CONFIG;
  const order   = systemOrder  || window.SUBSYSTEM_ORDER;
  const count   = order.length;
  const anomalies = order.filter(id => telemetry?.[id]?.status !== 'nominal').length;
  return (
    <aside className="sys-grid">
      <div className="panel-head">
        <span className="panel-title">{title || 'SUBSYSTEMS'}</span>
        <span className="panel-sub">{count - anomalies}/{count} NOMINAL</span>
      </div>
      <div className="sys-grid__list">
        {order.map(id => {
          const isOwned = highlightRole?.subsystems?.includes(id);
          return (
            <SubsystemCard key={id} id={id} data={telemetry?.[id]} compact={compact}
                           systemConfig={cfgMap}
                           highlight={isOwned ? highlightRole.color : null} />
          );
        })}
      </div>
    </aside>
  );
}
window.SubsystemGrid = SubsystemGrid;

// ── TopBar ─────────────────────────────────────────────
function TopBar({ remaining, isHolding, isComplete, onHold, onResume, onReset, speed, onSpeedChange, missionLabel, wordmark, onExit }) {
  const [now, setNow] = uS(new Date());
  uE(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const status = isComplete ? 'LAUNCH' : isHolding ? 'HOLD' : 'NOMINAL';
  const cls = isComplete ? 'status--launch' : isHolding ? 'status--hold' : 'status--nominal';
  const cdCls = isComplete ? 'countdown--launch' : isHolding ? 'countdown--hold' : '';

  return (
    <header className="topbar">
      <div className="topbar__left">
        {onExit && <button className="btn btn--ghost" onClick={onExit} style={{ marginRight: 6 }}>← MODE</button>}
        <span className="wordmark">{wordmark || 'ARIA'}</span>
        <span className="mission">{missionLabel || 'APEX-7 · AUTONOMOUS OPS'}</span>
      </div>
      <div className="topbar__center">
        <div className={`countdown ${cdCls}`}>
          {isComplete ? 'LAUNCH' : window.formatCountdown(remaining)}
        </div>
        <div className="countdown-ctrls">
          <button className="btn btn--hold" onClick={onHold} disabled={isHolding || isComplete}>HOLD</button>
          <button className="btn btn--resume" onClick={onResume} disabled={!isHolding || isComplete}>RESUME</button>
          <button className="btn btn--ghost" onClick={onReset}>↺ RESET</button>
        </div>
      </div>
      <div className="topbar__right">
        <div className="speed-ctl">
          <span className="speed-ctl__label">SPEED</span>
          <div className="speed-ctl__btns">
            {[1, 2, 5, 10].map(s => (
              <button key={s} className={`speed-btn ${speed === s ? 'active' : ''}`} onClick={() => onSpeedChange(s)}>{s}×</button>
            ))}
          </div>
        </div>
        <div className="live-clock">
          <span>UTC {now.toLocaleTimeString('en-US', { hour12: false, timeZone: 'UTC' })}</span>
        </div>
        <div className={`status-badge ${cls}`}>
          <span className="status-dot" />{status}
        </div>
      </div>
      {isHolding && <div className="hold-banner">⏸  COUNT HOLD — AWAITING RESUME</div>}
    </header>
  );
}
window.TopBar = TopBar;

// ── Approval Queue ─────────────────────────────────────
function ApprovalQueue({ remaining, pending, approved, log, onApprove, onHold, isHolding, isComplete, total }) {
  const approvedCount = approved.size;
  const logRef = uR(null);
  uE(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log.length]);

  const pctFill = (approvedCount / total) * 100;

  return (
    <section className="approval">
      <div className="panel-head">
        <span className="panel-title">AUTHORIZATION QUEUE</span>
        <span className="panel-sub">{approvedCount}/{total} APPROVED</span>
      </div>
      <div className="approval__progress">
        <div className="approval__progress-fill" style={{ width: `${pctFill}%` }} />
        {window.AUTONOMOUS_STEPS.map((s, i) => (
          <span key={s.id}
                className={`approval__tick ${approved.has(s.id) ? 'tick--done' : ''} ${pending?.id === s.id ? 'tick--active' : ''}`}
                style={{ left: `${(i / (total - 1)) * 100}%` }} />
        ))}
      </div>

      {isComplete ? (
        <div className="approval__done">
          <div className="approval__done-icon">◆</div>
          <div className="approval__done-title">LAUNCH COMMIT</div>
          <div className="approval__done-sub">ALL {total} ACTIONS AUTHORIZED · APEX-7 ASCENDING</div>
        </div>
      ) : pending ? (
        <div className={`approval__card ${pending.critical ? 'approval__card--critical' : ''}`}>
          <div className="approval__card-head">
            <span className="approval__step-num">
              STEP {window.AUTONOMOUS_STEPS.findIndex(s => s.id === pending.id) + 1}/{total}
            </span>
            <span className="approval__sys-badge"
                  style={{ color: window.SYSTEM_COLORS[pending.system], borderColor: window.SYSTEM_COLORS[pending.system] }}>
              {pending.system.replace('_', ' ')}
            </span>
          </div>
          <div className="approval__action">{pending.action}</div>
          <div className="approval__prompt">{pending.prompt}</div>
          {pending.critical && <div className="approval__warn">⚠  SAFETY-CRITICAL — VERIFY BEFORE APPROVING</div>}
          <div className="approval__btns">
            <button className="btn btn--approve" onClick={() => onApprove(pending)} disabled={isHolding}>
              ✓ AUTHORIZE
            </button>
            <button className="btn btn--hold-big" onClick={onHold}>⏸ HOLD</button>
          </div>
        </div>
      ) : (
        <div className="approval__idle">
          <div className="approval__idle-icon">◈</div>
          <div className="approval__idle-title">ARIA MONITORING</div>
          <div className="approval__idle-sub">AWAITING NEXT DECISION POINT</div>
        </div>
      )}

      <div className="approval__log" ref={logRef}>
        {log.length > 0 && <div className="approval__log-head">AUTHORIZATION LOG</div>}
        {log.map(e => (
          <div key={e.id} className="approval__log-item">
            <span className="approval__log-check">✓</span>
            <div className="approval__log-body">
              <div className="approval__log-action">{e.action}</div>
              <div className="approval__log-confirm">{e.confirm}</div>
            </div>
            <span className="approval__log-time">{window.formatTime(e.ts)}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
window.ApprovalQueue = ApprovalQueue;
