// ────────────────────────────────────────────────────────────────
// CONSOLE COPILOT mode — multi-role launch ops
// Uses same SUBSYSTEM_CONFIG as autonomous (shared rocket telemetry),
// but adds role metadata and radio chatter from data/modes.js
// ────────────────────────────────────────────────────────────────

window.COPILOT_ROLES = {
  FD:       { label: 'Flight Director', callsign: 'FLIGHT',   color: '#FF4D00', subsystems: ['PROPULSION','AVIONICS','GROUND_SUPPORT','RANGE_SAFETY','POWER','COMMS'], desc: 'Oversee the whole launch. All systems visible. Final authority on go/no-go.' },
  PROP:     { label: 'Propulsion',       callsign: 'PROP',     color: '#FF6B6B', subsystems: ['PROPULSION'],     desc: 'Propellant loading, tank pressure, chamber temps, igniter continuity.' },
  AVIONICS: { label: 'Avionics',         callsign: 'AVIONICS', color: '#00C97A', subsystems: ['AVIONICS'],       desc: 'Flight computer, GPS, IMU, bay thermal. Guidance GO/NO-GO caller.' },
  RSO:      { label: 'Range Safety',     callsign: 'RSO',      color: '#FFB300', subsystems: ['RANGE_SAFETY'],   desc: 'Airspace, wind, exclusion zones. Holds destruct authority.' },
  GSE:      { label: 'Ground Support',   callsign: 'GSE',      color: '#8A8FA8', subsystems: ['GROUND_SUPPORT'], desc: 'Pad-side pressurization, power, umbilicals. Retracts GSE at T-5:00.' },
  POWER:    { label: 'Power Systems',    callsign: 'POWER',    color: '#7EC8E3', subsystems: ['POWER'],          desc: '28V main bus, battery SOC, current draw. Internal power transfer.' },
  COMMS:    { label: 'Communications',   callsign: 'COMMS',    color: '#B8A9FA', subsystems: ['COMMS'],          desc: 'Telemetry uplink/downlink. Radio coordination across stations.' },
};

window.COPILOT_ROLE_ORDER = ['FD','PROP','AVIONICS','RSO','GSE','POWER','COMMS'];

// Radio chatter — full 23-line sequence from data/modes.js
window.COPILOT_RADIO = [
  { id: 'rc1',  triggerAt: 585, from: 'PROP',     text: 'Flight, Prop. Propellant loading complete. Tank pressures nominal.' },
  { id: 'rc2',  triggerAt: 572, from: 'FD',       text: 'Copy Prop. All stations, FD — proceed to subsystem power-on check.' },
  { id: 'rc3',  triggerAt: 548, from: 'AVIONICS', text: 'Flight, Avionics. Flight computer nominal. GPS locked, 12 sats.' },
  { id: 'rc4',  triggerAt: 525, from: 'GSE',      text: 'Flight, GSE. Ground support all nominal. GSE pressure 115 PSI.' },
  { id: 'rc5',  triggerAt: 503, from: 'RSO',      text: 'Flight, RSO. Safety brief complete. Airspace clearance confirmed.' },
  { id: 'rc6',  triggerAt: 478, from: 'COMMS',    text: 'Flight, Comms. All links up. Signal nominal at minus 67 dBm.' },
  { id: 'rc7',  triggerAt: 442, from: 'FD',       text: 'All stations, FD. Proceeding to avionics arm sequence. Stand by.' },
  { id: 'rc8',  triggerAt: 358, from: 'PROP',     text: 'Flight, Prop. Pressurization complete. Chamber ready.' },
  { id: 'rc9',  triggerAt: 292, from: 'AVIONICS', text: 'Flight, Avionics. Final flight computer check complete. GO.' },
  { id: 'rc10', triggerAt: 268, from: 'GSE',      text: 'Flight, GSE. Umbilical disconnect ready on your mark.' },
  { id: 'rc11', triggerAt: 238, from: 'POWER',    text: 'Flight, Power. Internal battery transfer complete. Bus at 28.2V.' },
  { id: 'rc12', triggerAt: 208, from: 'RSO',      text: 'Flight, RSO. Destruct system armed. Range is GREEN.' },
  { id: 'rc13', triggerAt: 178, from: 'SAFETY',   text: 'Flight, Safety. Pad area clear. All personnel beyond safe radius.' },
  { id: 'rc14', triggerAt: 148, from: 'AVIONICS', text: 'Flight, Avionics. Final verification complete. GO for launch.' },
  { id: 'rc15', triggerAt: 118, from: 'PROP',     text: 'Flight, Prop. Igniter continuity confirmed. GO for ignition.' },
  { id: 'rc16', triggerAt: 58,  from: 'RSO',      text: 'Flight, RSO. Range safety clearance granted. GO for launch commit.' },
  { id: 'rc17', triggerAt: 43,  from: 'FD',       text: 'All stations — go/no-go poll. Prop?' },
  { id: 'rc18', triggerAt: 41,  from: 'PROP',     text: 'GO.' },
  { id: 'rc19', triggerAt: 39,  from: 'AVIONICS', text: 'GO.' },
  { id: 'rc20', triggerAt: 37,  from: 'RSO',      text: 'GO.' },
  { id: 'rc21', triggerAt: 35,  from: 'GSE',      text: 'GO.' },
  { id: 'rc22', triggerAt: 33,  from: 'COMMS',    text: 'GO.' },
  { id: 'rc23', triggerAt: 29,  from: 'FD',       text: 'Flight is GO. Proceeding to launch commit. Good luck, APEX-7.' },
];

// Copilot ARIA timeline — emphasizes coaching the operator in their role
window.COPILOT_ARIA_TIMELINE = [
  { id: 'ca0', triggerAt: 598, type: 'system',  text: 'ARIA online. Console copilot mode. I\'ll flag anything relevant to your role and keep you oriented across the loop.' },
  { id: 'ca1', triggerAt: 555, type: 'info',    text: 'Flight is moving through power-on check. No action required yet. I\'ll ping you when your systems come up.', reasoning: 'Current phase: PRE-LAUNCH subsystem power-on. Next role-specific callout per console role.' },
  { id: 'ca2', triggerAt: 440, type: 'info',    text: 'Avionics arm sequence initiating. Stand by for your call sign on the loop.' },
  { id: 'ca3', triggerAt: 300, type: 'warning', text: 'T-5:00. Entering terminal count. Listen for your GO/NO-GO call from FD.', reasoning: 'Terminal-count polls run cadenced at T-5:00, T-1:00, and T-0:45. Miss your call = automatic NO-GO.' },
  { id: 'ca4', triggerAt: 270, type: 'warning', text: 'Avionics bay temp reading 2.3°C above baseline. Watch your console if you\'re Avionics or FD.', reasoning: 'Flagged as monitor-only. Below hold-threshold (+4°C). No action required yet.', anomaly: true },
  { id: 'ca5', triggerAt: 180, type: 'info',    text: 'Bay temp stabilizing. Likely sensor artifact. Confidence benign: 94%.' },
  { id: 'ca6', triggerAt: 120, type: 'info',    text: 'T-2:00. Range GREEN. Vehicle on internal power. Prepare for go/no-go poll at T-45s.' },
  { id: 'ca7', triggerAt: 45,  type: 'warning', text: 'Go/no-go poll running now. Answer promptly with your call sign.' },
  { id: 'ca8', triggerAt: 12,  type: 'launch',  text: 'LAUNCH COMMIT. T-10 and counting. Clean loop, team.' },
];
