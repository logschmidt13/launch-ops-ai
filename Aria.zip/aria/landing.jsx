// Landing screen + Role picker (copilot first step)
function LandingScreen({ onSelect }) {
  const MODES = [
    { id: 'copilot',    num: '01', title: 'CONSOLE COPILOT',   tag: 'MULTI-ROLE · LAUNCH OPS',   desc: 'Select your console role and monitor your systems. ARIA listens to all radio channels and keeps you in the loop.' },
    { id: 'fsae',       num: '02', title: 'FSAE RACE ENGINEER', tag: 'MOTORSPORT · FORMULA SAE',  desc: 'Pre-race sequence and live vehicle telemetry for Formula SAE teams. From driver brief to green flag.' },
    { id: 'autonomous', num: '03', title: 'AUTONOMOUS OPS',     tag: 'SOLO · ATC STYLE',          desc: 'ARIA runs the show. One operator, one click to approve each step. ATC-style mission control.' },
  ];
  return (
    <div className="landing" data-screen-label="00 Landing">
      <div className="landing__bg" />
      <div className="landing__head">
        <div className="landing__mark">
          <span className="landing__wordmark">ARIA</span>
          <span className="landing__tag">AUTONOMOUS RANGE INTELLIGENCE ASSISTANT</span>
        </div>
        <div className="landing__prompt">SELECT OPERATING MODE TO CONTINUE</div>
      </div>
      <div className="landing__cards">
        {MODES.map(m => (
          <button key={m.id} className="mode-card" onClick={() => onSelect(m.id)}>
            <span className="mode-card__num">MODE {m.num}</span>
            <div className="mode-card__title">{m.title}</div>
            <div className="mode-card__tag">{m.tag}</div>
            <div className="mode-card__desc">{m.desc}</div>
            <span className="mode-card__cta">ENTER →</span>
          </button>
        ))}
      </div>
      <div className="landing__foot">APEX-7 · STUDENT LAUNCH INITIATIVE · ALL SYSTEMS NOMINAL</div>
    </div>
  );
}
window.LandingScreen = LandingScreen;

function RolePicker({ onSelect, onBack }) {
  return (
    <div className="role-picker" data-screen-label="00 Copilot Role">
      <div className="landing__bg" />
      <div className="landing__head">
        <div className="landing__mark">
          <span className="landing__wordmark">ARIA</span>
          <span className="landing__tag">CONSOLE COPILOT · MODE 01</span>
        </div>
        <div className="landing__prompt">SELECT YOUR CONSOLE ROLE</div>
        <div className="role-picker__sub">YOUR SYSTEMS AND CHECKLIST ITEMS WILL BE HIGHLIGHTED. ARIA WILL SURFACE WHAT'S RELEVANT TO YOU.</div>
      </div>
      <div className="role-grid">
        {window.COPILOT_ROLE_ORDER.map(id => {
          const r = window.COPILOT_ROLES[id];
          return (
            <button key={id} className="role-card" onClick={() => onSelect(id)}
                    style={{ '--role-color': r.color }}>
              <div className="role-card__head">
                <span className="role-card__callsign" style={{ color: r.color }}>{r.callsign}</span>
                {id === 'FD' && <span className="role-card__badge">LEAD</span>}
              </div>
              <div className="role-card__label">{r.label}</div>
              <div className="role-card__systems">
                {r.subsystems.length ? r.subsystems.map(s => s.replace(/_/g, ' ')).join(' · ') : 'ALL SYSTEMS'}
              </div>
              <div className="role-card__desc">{r.desc}</div>
            </button>
          );
        })}
      </div>
      <button className="landing__back" onClick={onBack}>← BACK TO MODE SELECT</button>
    </div>
  );
}
window.RolePicker = RolePicker;
