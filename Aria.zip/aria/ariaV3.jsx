// ARIA v3 — Ambient + summonable command overlay (Cmd-K style)
const { useState: v3S, useEffect: v3E, useRef: v3R, useMemo: v3M } = React;

function AriaV3Overlay({ open, onClose, messages, telemetry, remaining, onSend }) {
  const [input, setInput] = v3S('');
  const inputRef = v3R(null);
  const listRef = v3R(null);

  v3E(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  v3E(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages.length, open]);

  v3E(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  if (!open) return null;

  const send = (text) => {
    const raw = (text ?? input).trim();
    if (!raw) return;
    setInput('');
    onSend(raw);
  };

  return (
    <div className="aria-v3__backdrop" onClick={onClose}>
      <div className="aria-v3__modal" onClick={e => e.stopPropagation()}>
        <div className="aria-v3__modal-head">
          <span className="aria-v3__modal-tag">ARIA</span>
          <span className="aria-v3__modal-sub">Autonomous Range Intelligence Assistant</span>
          <span className="aria-v3__modal-esc">ESC to close</span>
        </div>

        <div className="aria-v3__list" ref={listRef}>
          {messages.map(m => (
            <div key={m.id} className={`v3-msg v3-msg--${m.type}`}>
              <span className="v3-msg__tag">{m.type === 'user' ? 'YOU' : 'ARIA'}</span>
              <div className="v3-msg__body">
                <div className="v3-msg__text">{m.text}</div>
                {m.reasoning && (
                  <div className="v3-msg__reason">
                    <span>▸ REASONING</span> {m.reasoning}
                  </div>
                )}
              </div>
              <span className="v3-msg__time">{window.formatTime(m.timestamp)}</span>
            </div>
          ))}
        </div>

        <div className="aria-v3__chips">
          <button className="chip" onClick={() => send('status')}>status</button>
          <button className="chip" onClick={() => send('explain avionics')}>explain avionics</button>
          <button className="chip" onClick={() => send('hold')}>hold</button>
          <button className="chip" onClick={() => send('help')}>help</button>
        </div>

        <div className="aria-v3__input">
          <span className="aria-v3__caret">❯</span>
          <input
            ref={inputRef}
            className="aria-v3__field"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') send(); }}
            placeholder="Ask ARIA or type a command…"
          />
          <kbd className="aria-v3__kbd">↵</kbd>
        </div>
      </div>
    </div>
  );
}

// v3 main panel inside the app area — just shows status + a large "summon" button
function AriaV3Dock({ messages, remaining, onSummon }) {
  const latest = v3M(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].type !== 'user') return messages[i];
    }
    return null;
  }, [messages]);

  const anomaly = latest?.anomaly || latest?.type === 'warning';

  return (
    <aside className="aria-v3__dock">
      <div className="panel-head">
        <span className="panel-title">ARIA</span>
        <span className="panel-sub">AMBIENT MODE</span>
      </div>

      <div className="aria-v3__dock-body">
        <div className={`aria-v3__glyph ${anomaly ? 'aria-v3__glyph--warn' : ''}`}>
          <span className="aria-v3__glyph-dot" />
          <span className="aria-v3__glyph-dot" />
          <span className="aria-v3__glyph-dot" />
        </div>
        <div className="aria-v3__status">
          {anomaly ? 'ANOMALY TRACKED' : 'ALL NOMINAL'}
        </div>
        <div className="aria-v3__lastwords">
          {latest ? `"${latest.text.slice(0, 140)}${latest.text.length > 140 ? '…' : ''}"` : 'Standing by.'}
        </div>
      </div>

      <button className="aria-v3__summon" onClick={onSummon}>
        <span>SUMMON ARIA</span>
        <kbd>⌘K</kbd>
      </button>

      <div className="aria-v3__hint">
        ARIA runs ambiently. Summon to converse.
      </div>
    </aside>
  );
}

window.AriaV3Overlay = AriaV3Overlay;
window.AriaV3Dock = AriaV3Dock;
