// ARIA v2 — Cinematic centerpiece: voice waveform, reasoning inline, quick chips
const { useState: v2S, useEffect: v2E, useRef: v2R, useMemo: v2M } = React;

// ── Animated voice waveform (CSS-only-ish, driven by message arrivals) ──
function Waveform({ speaking, idle }) {
  const bars = 24;
  return (
    <div className={`wav ${speaking ? 'wav--speak' : ''} ${idle ? 'wav--idle' : ''}`}>
      {Array.from({ length: bars }).map((_, i) => (
        <span key={i} className="wav__bar" style={{ '--i': i, '--d': `${(i * 37) % 900}ms` }} />
      ))}
    </div>
  );
}

// Orbit ring around the waveform
function OrbitRing({ anomaly }) {
  return (
    <svg className="orbit" viewBox="0 0 200 200" width="100%" height="100%">
      <defs>
        <linearGradient id="ogr" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%"  stopColor={anomaly ? '#FFB300' : '#FF4D00'} stopOpacity="0.9"/>
          <stop offset="100%" stopColor={anomaly ? '#FFB300' : '#FF4D00'} stopOpacity="0.1"/>
        </linearGradient>
      </defs>
      <circle cx="100" cy="100" r="90" fill="none" stroke="#1C2240" strokeWidth="1" />
      <circle cx="100" cy="100" r="76" fill="none" stroke="#1C2240" strokeWidth="1" strokeDasharray="2 6" />
      <circle cx="100" cy="100" r="90" fill="none" stroke="url(#ogr)" strokeWidth="2"
              strokeDasharray="40 500" strokeLinecap="round" className="orbit__sweep" />
      <circle cx="100" cy="100" r="60" fill="none" stroke="#1C2240" strokeWidth="1" />
    </svg>
  );
}

function AriaV2({ messages, telemetry, remaining, isHolding, onSend, accent }) {
  const [input, setInput] = v2S('');
  const [showReasoning, setShowReasoning] = v2S(true);
  const [speaking, setSpeaking] = v2S(false);
  const timer = v2R(null);

  // Latest assistant message (not user)
  const latest = v2M(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].type !== 'user') return messages[i];
    }
    return null;
  }, [messages]);

  // History excluding latest & user messages too recent (keep a scrolling log below)
  const history = v2M(
    () => messages.filter(m => m !== latest).slice(-6),
    [messages, latest]
  );

  // Trigger "speaking" animation for 2.2s each time a new ARIA msg arrives
  v2E(() => {
    if (!latest) return;
    setSpeaking(true);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setSpeaking(false), 2200);
  }, [latest?.id]);

  const send = (text) => {
    const raw = (text ?? input).trim();
    if (!raw) return;
    setInput('');
    onSend(raw);
  };

  const anomaly = latest?.anomaly || latest?.type === 'warning';
  const isLaunch = latest?.type === 'launch';
  const isOk = latest?.type === 'success';

  const statusColor = isLaunch ? '#FF4D00' : anomaly ? '#FFB300' : isOk ? '#00C97A' : accent || '#FF4D00';

  return (
    <section className="aria-v2" style={{ '--aria-accent': statusColor }}>
      {/* ── Stage: orb + waveform + call-out ────────────── */}
      <div className="aria-v2__stage">
        <div className="aria-v2__orb-wrap">
          <OrbitRing anomaly={anomaly} />
          <div className="aria-v2__orb-core">
            <Waveform speaking={speaking} idle={!speaking} />
            <div className="aria-v2__orb-label">ARIA</div>
            <div className="aria-v2__orb-sub">{speaking ? 'SPEAKING' : isHolding ? 'HOLDING' : 'LISTENING'}</div>
          </div>
        </div>

        <div className="aria-v2__meta">
          <div className="aria-v2__meta-row">
            <span className="aria-v2__meta-k">MISSION</span>
            <span className="aria-v2__meta-v">APEX-7</span>
          </div>
          <div className="aria-v2__meta-row">
            <span className="aria-v2__meta-k">MODE</span>
            <span className="aria-v2__meta-v">AUTONOMOUS</span>
          </div>
          <div className="aria-v2__meta-row">
            <span className="aria-v2__meta-k">T-MINUS</span>
            <span className="aria-v2__meta-v">{window.formatCountdown(remaining)}</span>
          </div>
          <div className="aria-v2__meta-row">
            <span className="aria-v2__meta-k">HEALTH</span>
            <span className="aria-v2__meta-v" style={{ color: anomaly ? '#FFB300' : '#00C97A' }}>
              {anomaly ? 'ANOMALY' : 'NOMINAL'}
            </span>
          </div>
        </div>
      </div>

      {/* ── Latest utterance ─────────────────────────────── */}
      <div className={`aria-v2__utterance ${anomaly ? 'aria-v2__utterance--warn' : ''} ${isLaunch ? 'aria-v2__utterance--launch' : ''} ${isOk ? 'aria-v2__utterance--ok' : ''}`}>
        {latest ? (
          <>
            <div className="aria-v2__utt-head">
              <span className="aria-v2__utt-tag">ARIA · {latest.type?.toUpperCase() ?? 'INFO'}</span>
              <span className="aria-v2__utt-time">{window.formatTime(latest.timestamp)}</span>
            </div>
            <div className="aria-v2__utt-text">{latest.text}</div>
            {latest.reasoning && showReasoning && (
              <div className="aria-v2__utt-reason">
                <span className="aria-v2__utt-reason-tag">▸ REASONING</span>
                <div>{latest.reasoning}</div>
              </div>
            )}
            {latest.reasoning && (
              <button className="aria-v2__reason-toggle" onClick={() => setShowReasoning(s => !s)}>
                {showReasoning ? 'HIDE REASONING' : 'SHOW REASONING'}
              </button>
            )}
          </>
        ) : (
          <div className="aria-v2__utt-text">Initializing…</div>
        )}
      </div>

      {/* ── Recent channel log ───────────────────────────── */}
      <div className="aria-v2__history">
        <div className="aria-v2__history-head">CHANNEL LOG</div>
        {history.length === 0 && <div className="aria-v2__history-empty">No prior messages.</div>}
        {history.slice().reverse().map(m => (
          <div key={m.id} className={`aria-v2__hist-item aria-v2__hist-item--${m.type}`}>
            <span className="aria-v2__hist-time">{window.formatTime(m.timestamp)}</span>
            <span className="aria-v2__hist-tag">{m.type === 'user' ? 'YOU' : 'ARIA'}</span>
            <span className="aria-v2__hist-text">{m.text}</span>
          </div>
        ))}
      </div>

      {/* ── Quick chips + input ──────────────────────────── */}
      <div className="aria-v2__chips">
        <button className="chip" onClick={() => send('status')}>▸ System status</button>
        <button className="chip" onClick={() => send('explain avionics')}>▸ Explain avionics</button>
        <button className="chip" onClick={() => send('explain propulsion')}>▸ Explain propulsion</button>
        <button className="chip" onClick={() => send('hold')}>▸ Hold status</button>
      </div>

      <div className="aria-v2__input">
        <input
          className="aria-v2__field"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') send(); }}
          placeholder="Ask ARIA…"
          maxLength={200}
        />
        <button className="aria-v2__send" onClick={() => send()}>TRANSMIT ↵</button>
      </div>
    </section>
  );
}
window.AriaV2 = AriaV2;
