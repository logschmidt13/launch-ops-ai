// ARIA v1 — Polished sidebar chat (refinement of original)
const { useState: v1S, useEffect: v1E, useRef: v1R } = React;

function AriaV1({ messages, telemetry, isHolding, remaining, onSend }) {
  const [input, setInput] = v1S('');
  const bottomRef = v1R(null);

  v1E(() => {
    if (bottomRef.current) bottomRef.current.parentElement.scrollTop = bottomRef.current.parentElement.scrollHeight;
  }, [messages.length]);

  const send = () => {
    const raw = input.trim();
    if (!raw) return;
    setInput('');
    onSend(raw);
  };

  const typeClass = (t) => ({
    system: 'msg--system', info: 'msg--info', warning: 'msg--warn',
    success: 'msg--ok', launch: 'msg--launch', user: 'msg--user', response: 'msg--resp',
  }[t] || 'msg--info');

  return (
    <aside className="aria-v1">
      <div className="aria-v1__head">
        <div className="aria-v1__title-row">
          <span className="aria-v1__pulse" />
          <span className="aria-v1__title">ARIA</span>
          <span className="aria-v1__subtitle">Autonomous Range Intelligence Assistant</span>
        </div>
        <span className="aria-v1__badge">ONLINE</span>
      </div>

      <div className="aria-v1__stream">
        {messages.map(m => (
          <div key={m.id} className={`msg ${typeClass(m.type)}`}>
            <div className="msg__head">
              <span className="msg__tag">{m.type === 'user' ? 'YOU' : 'ARIA'}</span>
              {m.type !== 'user' && m.anomaly && <span className="msg__pill">ANOMALY</span>}
              <span className="msg__time">{window.formatTime(m.timestamp)}</span>
            </div>
            <div className="msg__text">{m.text}</div>
            {m.reasoning && (
              <details className="msg__reason">
                <summary>REASONING</summary>
                <div>{m.reasoning}</div>
              </details>
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="aria-v1__input">
        <div className="aria-v1__hint">
          Try: <code>status</code> · <code>explain avionics</code> · <code>help</code>
        </div>
        <div className="aria-v1__row">
          <input
            className="aria-v1__field"
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter') send(); }}
            placeholder="Ask ARIA anything…"
            maxLength={200}
          />
          <button className="aria-v1__send" onClick={send}>SEND ↵</button>
        </div>
      </div>
    </aside>
  );
}
window.AriaV1 = AriaV1;
