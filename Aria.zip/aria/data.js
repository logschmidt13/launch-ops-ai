// ────────────────────────────────────────────────────────────────
// Shared mission data — adapted from logschmidt13/launch-ops-ai
// ────────────────────────────────────────────────────────────────

window.SUBSYSTEM_CONFIG = {
  PROPULSION: {
    label: 'PROPULSION',
    primaryMetric: 'oxTankPres',
    metrics: [
      { key: 'oxTankPres',   label: 'OX TANK PRES', unit: 'PSI', base: 847,  variance: 3,   decimals: 0 },
      { key: 'fuelTemp',     label: 'FUEL TEMP',    unit: '°C',  base: 18.4, variance: 0.4, decimals: 1 },
      { key: 'chamberPres',  label: 'CHAMBER PRES', unit: 'PSI', base: 0,    variance: 0.2, decimals: 1 },
    ],
  },
  AVIONICS: {
    label: 'AVIONICS',
    primaryMetric: 'bayTemp',
    metrics: [
      { key: 'bayTemp',  label: 'BAY TEMP',  unit: '°C', base: 24.1, variance: 0.3, decimals: 1 },
      { key: 'cpuLoad',  label: 'CPU LOAD',  unit: '%',  base: 23,   variance: 4,   decimals: 0 },
      { key: 'gpsSats',  label: 'GPS SATS',  unit: '',   base: 12,   variance: 1,   decimals: 0 },
    ],
  },
  GROUND_SUPPORT: {
    label: 'GROUND SUPPORT',
    primaryMetric: 'gsePressure',
    metrics: [
      { key: 'gsePressure', label: 'GSE PRES',  unit: 'PSI', base: 115,  variance: 2,   decimals: 0 },
      { key: 'padTemp',     label: 'PAD TEMP',  unit: '°C',  base: 31.2, variance: 0.5, decimals: 1 },
      { key: 'humidity',    label: 'HUMIDITY',  unit: '%',   base: 42,   variance: 2,   decimals: 0 },
    ],
  },
  RANGE_SAFETY: {
    label: 'RANGE SAFETY',
    primaryMetric: 'windSpeed',
    metrics: [
      { key: 'windSpeed', label: 'WIND SPD', unit: 'kts', base: 8.4,  variance: 1.5, decimals: 1 },
      { key: 'windDir',   label: 'WIND DIR', unit: '°',   base: 247,  variance: 5,   decimals: 0 },
      { key: 'visibility',label: 'VIS',      unit: 'mi',  base: 10.0, variance: 0.2, decimals: 1 },
    ],
  },
  POWER: {
    label: 'POWER',
    primaryMetric: 'busVoltage',
    metrics: [
      { key: 'busVoltage',  label: 'BUS VOLT',  unit: 'V', base: 28.2, variance: 0.1, decimals: 1 },
      { key: 'currentDraw', label: 'CURRENT',   unit: 'A', base: 4.7,  variance: 0.3, decimals: 1 },
      { key: 'batterySoc',  label: 'BATT SOC',  unit: '%', base: 98,   variance: 0.5, decimals: 0 },
    ],
  },
  COMMS: {
    label: 'COMMS',
    primaryMetric: 'signalStr',
    metrics: [
      { key: 'signalStr',    label: 'SIGNAL',    unit: 'dBm',  base: -67,  variance: 2,  decimals: 0 },
      { key: 'uplinkRate',   label: 'UPLINK',    unit: 'Kbps', base: 512,  variance: 20, decimals: 0 },
      { key: 'downlinkRate', label: 'DOWNLINK',  unit: 'Kbps', base: 1024, variance: 30, decimals: 0 },
    ],
  },
};

window.SUBSYSTEM_ORDER = ['PROPULSION', 'AVIONICS', 'GROUND_SUPPORT', 'RANGE_SAFETY', 'POWER', 'COMMS'];

window.SYSTEM_COLORS = {
  AVIONICS:       '#00C97A',
  PROPULSION:     '#FF6B6B',
  RANGE_SAFETY:   '#FFB300',
  POWER:          '#7EC8E3',
  COMMS:          '#B8A9FA',
  GROUND_SUPPORT: '#8A8FA8',
};

// ARIA timeline (autonomous ops) — broadcast messages keyed to T-time
window.ARIA_TIMELINE = [
  { id: 'aa0', triggerAt: 598, type: 'system',  text: 'ARIA online. Autonomous operations mode active. I\'ll manage the launch sequence and request your authorization at each decision point.' },
  { id: 'aa1', triggerAt: 480, type: 'info',    text: 'Onboard systems nominal. Internal power active. Proceeding through pre-launch checklist autonomously.', reasoning: 'All 6 subsystems reporting within baseline. Bus voltage 28.2V stable. No action required.' },
  { id: 'aa2', triggerAt: 300, type: 'warning', text: 'T-5:00. Entering terminal count. All remaining actions require your explicit authorization.', reasoning: 'Response latency becomes a launch-window risk past this point. Budget 15s/decision.' },
  { id: 'aa3', triggerAt: 270, type: 'warning', text: 'ANOMALY — Avionics bay temp reading 2.3°C above baseline (26.4°C vs 24.1°C). Monitoring trend. No action required yet.', reasoning: 'Likely sensor drift or minor airflow disruption. Confidence anomaly is benign: 68%. Will alert if trend continues past T-2:00.', anomaly: true },
  { id: 'aa4', triggerAt: 180, type: 'info',    text: 'Avionics bay temp stabilizing. Delta returning toward baseline. Continue count.', reasoning: 'Peak was +2.3°C at T-4:20, now +0.6°C. Confidence benign: 94%.' },
  { id: 'aa5', triggerAt: 120, type: 'info',    text: 'T-2:00. Range is GREEN. Vehicle self-sustaining on internal power. All systems nominal.' },
  { id: 'aa6', triggerAt: 60,  type: 'warning', text: 'T-1:00. Final two authorization requests remaining. Ignition arm and launch commit. Remain at your station.' },
  { id: 'aa7', triggerAt: 10,  type: 'launch',  text: 'LAUNCH COMMIT ARMED. Ignition sequence pending your final approval. T-10 and counting.' },
];

window.AUTONOMOUS_STEPS = [
  { id: 'as1',  triggerAt: 590, system: 'AVIONICS',       action: 'Initialize flight computer',             prompt: 'Power on flight computer and load APEX-7 mission parameters.', confirm: 'Flight computer nominal. Mission parameters loaded. GPS lock: 12 satellites.' },
  { id: 'as2',  triggerAt: 558, system: 'PROPULSION',     action: 'Begin propellant loading',               prompt: 'Initiate oxidizer loading. Pad exclusion zone confirmed clear.', confirm: 'Propellant loading initiated. Tank pressure rising nominally. ETA to full load: 3 min.' },
  { id: 'as3',  triggerAt: 520, system: 'RANGE_SAFETY',   action: 'Establish range safety link',            prompt: 'Arm range safety uplink and transmit vehicle ID to range control.', confirm: 'Range safety link established. Range is GREEN.' },
  { id: 'as4',  triggerAt: 488, system: 'POWER',          action: 'Activate onboard power bus',             prompt: 'Switch vehicle to internal battery power. Estimated bus life: 45 min.', confirm: 'Onboard power bus active. Bus voltage 28.4V. All rails nominal.' },
  { id: 'as5',  triggerAt: 452, system: 'COMMS',          action: 'Verify telemetry downlink',              prompt: 'Activate telemetry transmitter and verify ground station lock.', confirm: 'Telemetry downlink confirmed. Signal −67 dBm. 1 Mbps.' },
  { id: 'as6',  triggerAt: 415, system: 'AVIONICS',       action: 'Arm flight termination system',          prompt: 'Arm FTS. Safety-critical — confirm pad area is clear.', confirm: 'FTS armed. Safe-arm verified. RSO has destruct authority.' },
  { id: 'as7',  triggerAt: 370, system: 'PROPULSION',     action: 'Close loading valves and pressurize',    prompt: 'Close loading valves and begin tank pressurization.', confirm: 'Valves closed. Propellant mass within 0.2% of target.' },
  { id: 'as8',  triggerAt: 320, system: 'GROUND_SUPPORT', action: 'Retract ground support equipment',       prompt: 'Begin GSE retraction. Umbilicals and service arms disengage.', confirm: 'GSE retracted. Vehicle is self-sustaining.' },
  { id: 'as9',  triggerAt: 270, system: 'AVIONICS',       action: 'Execute terminal avionics check',        prompt: 'Run terminal avionics verification. All 47 channels polled.', confirm: 'Terminal check complete. Guidance GO for launch.' },
  { id: 'as10', triggerAt: 210, system: 'RANGE_SAFETY',   action: 'Obtain launch window clearance',         prompt: 'Contact range control and request launch window clearance.', confirm: 'Range clearance granted. Window open T-3:30 to T+2:00.' },
  { id: 'as11', triggerAt: 155, system: 'PROPULSION',     action: 'Initiate engine chill-down',             prompt: 'Begin engine pre-conditioning chill-down sequence.', confirm: 'Chill-down in progress. ETA 90s.' },
  { id: 'as12', triggerAt: 90,  system: 'AVIONICS',       action: 'Transfer to internal guidance',          prompt: 'Cut ground guidance umbilical. Switch to full autonomous flight.', confirm: 'Internal guidance active. Ground link read-only.' },
  { id: 'as13', triggerAt: 45,  system: 'PROPULSION',     action: 'Arm ignition circuit',                   prompt: 'FINAL AUTHORIZATION. Arm pyrotechnic ignition circuit. Point of no return.', confirm: 'Ignition armed. Continuity confirmed. Commit authority locked.', critical: true },
  { id: 'as14', triggerAt: 12,  system: 'AVIONICS',       action: 'Execute launch commit',                  prompt: 'ALL SYSTEMS GO. Final launch commit. This initiates ignition.', confirm: 'Launch commit received. Liftoff in T-10 and counting.', critical: true },
];

window.SUBSYSTEM_EXPLANATIONS = {
  PROPULSION:     'Monitors oxidizer tank pressure (nominal: 847 PSI), fuel line temperature, and chamber pressure. Currently pre-ignition standby.',
  AVIONICS:       'Flight computer, GPS (12 sats), and IMU. Bay temperature is the key health indicator — nominal 22–26°C.',
  GROUND_SUPPORT: 'Ground-side pressurization, power, and umbilical connections. GSE 115 PSI nominal.',
  RANGE_SAFETY:   'Flight corridor integrity, wind conditions, exclusion zones. Wind 8.4 kts / 247° — within 15 kt limit. Range CLEAR.',
  POWER:          '28V main bus, battery SOC, current draw. SOC 98%. Bus 28.2V nominal.',
  COMMS:          'Telemetry uplink and downlink. Signal −67 dBm (excellent). Uplink 512K, downlink 1024K.',
};
