// ────────────────────────────────────────────────────────────────
// FSAE RACE ENGINEER mode — adapted from data/fsae.js
// ────────────────────────────────────────────────────────────────

window.FSAE_SUBSYSTEM_CONFIG = {
  POWERTRAIN: {
    label: 'POWERTRAIN',
    primaryMetric: 'rpm',
    metrics: [
      { key: 'rpm',        label: 'ENGINE RPM',   unit: ' rpm' },
      { key: 'throttle',   label: 'THROTTLE',     unit: '%'    },
      { key: 'waterTemp',  label: 'WATER TEMP',   unit: '°C'   },
      { key: 'oilPress',   label: 'OIL PRES',     unit: ' bar' },
    ],
  },
  AERO: {
    label: 'AERO PACKAGE',
    primaryMetric: 'frontDF',
    metrics: [
      { key: 'frontDF',     label: 'FRONT DF',    unit: ' N'   },
      { key: 'rearDF',      label: 'REAR DF',     unit: ' N'   },
      { key: 'rideHeightF', label: 'RH FRONT',    unit: ' mm'  },
      { key: 'rideHeightR', label: 'RH REAR',     unit: ' mm'  },
    ],
  },
  SUSPENSION: {
    label: 'SUSPENSION',
    primaryMetric: 'rollAngle',
    metrics: [
      { key: 'rollAngle',  label: 'ROLL ANGLE',   unit: '°'    },
      { key: 'flTravel',   label: 'FL TRAVEL',    unit: ' mm'  },
      { key: 'frTravel',   label: 'FR TRAVEL',    unit: ' mm'  },
      { key: 'tireTemp',   label: 'FL TIRE TEMP', unit: '°C'   },
    ],
  },
  DAQ: {
    label: 'DATA ACQ',
    primaryMetric: 'dataRate',
    metrics: [
      { key: 'dataRate',   label: 'LOG RATE',     unit: ' Hz'  },
      { key: 'canLoad',    label: 'CAN BUS',      unit: '%'    },
      { key: 'gpsLock',    label: 'GPS SATS',     unit: ''     },
      { key: 'storage',    label: 'STORAGE',      unit: ' MB'  },
    ],
  },
  DRIVER: {
    label: 'DRIVER INPUTS',
    primaryMetric: 'gLat',
    metrics: [
      { key: 'gLat',       label: 'LAT G',        unit: 'g'    },
      { key: 'gLon',       label: 'LONG G',       unit: 'g'    },
      { key: 'steer',      label: 'STEER',        unit: '°'    },
      { key: 'brakePres',  label: 'BRAKE',        unit: ' bar' },
    ],
  },
  RACE_CONTROL: {
    label: 'RACE CONTROL',
    primaryMetric: 'fuelLevel',
    metrics: [
      { key: 'lapNum',     label: 'LAP',          unit: ''     },
      { key: 'lapTime',    label: 'LAST LAP',     unit: 's'    },
      { key: 'bestLap',    label: 'BEST LAP',     unit: 's'    },
      { key: 'fuelLevel',  label: 'FUEL',         unit: '%'    },
    ],
  },
};

window.FSAE_SUBSYSTEM_ORDER = ['POWERTRAIN', 'AERO', 'SUSPENSION', 'DAQ', 'DRIVER', 'RACE_CONTROL'];

window.FSAE_SYSTEM_COLORS = {
  POWERTRAIN:   '#FF6B6B',
  AERO:         '#7EC8E3',
  SUSPENSION:   '#B8A9FA',
  DAQ:          '#00C97A',
  DRIVER:       '#FFB300',
  RACE_CONTROL: '#FF4D00',
};

window.FSAE_CHECKLIST_ITEMS = [
  { id: 'fc1',  phase: 'PRE-GRID',   name: 'Tyre pressures verified — 12 PSI all round',  role: 'MECH',       triggerAt: 290, type: 'manual' },
  { id: 'fc2',  phase: 'PRE-GRID',   name: 'Fuel load confirmed — 4.0 L',                 role: 'FUELS',      triggerAt: 275, type: 'auto'   },
  { id: 'fc3',  phase: 'PRE-GRID',   name: 'DAQ logging armed at 100 Hz',                 role: 'DAQ',        triggerAt: 260, type: 'auto'   },
  { id: 'fc4',  phase: 'PRE-GRID',   name: 'Driver weight ballast installed',             role: 'MECH',       triggerAt: 240, type: 'manual' },
  { id: 'fc5',  phase: 'PRE-GRID',   name: 'Wing elements torque-checked',                role: 'AERO',       triggerAt: 220, type: 'manual' },
  { id: 'fc6',  phase: 'PRE-GRID',   name: 'Engine warm-up cycle complete',               role: 'POWERTRAIN', triggerAt: 195, type: 'auto'   },
  { id: 'fc7',  phase: 'FORMATION',  name: 'Driver strapped in',                          role: 'DRIVER',     triggerAt: 178, type: 'manual' },
  { id: 'fc8',  phase: 'FORMATION',  name: 'HANS device and helmet connected',            role: 'SAFETY',     triggerAt: 162, type: 'manual' },
  { id: 'fc9',  phase: 'FORMATION',  name: 'Radio check — driver comms nominal',          role: 'COMMS',      triggerAt: 142, type: 'auto'   },
  { id: 'fc10', phase: 'FORMATION',  name: 'Transponder active',                          role: 'DAQ',        triggerAt: 122, type: 'auto'   },
  { id: 'fc11', phase: 'FORMATION',  name: 'Brake bias set — 60% front',                  role: 'DRIVER',     triggerAt: 102, type: 'manual' },
  { id: 'fc12', phase: 'FORMATION',  name: 'TC map 3 selected',                           role: 'POWERTRAIN', triggerAt: 82,  type: 'manual' },
  { id: 'fc13', phase: 'RACE START', name: 'Race Control grid clearance received',        role: 'RC',         triggerAt: 58,  type: 'auto'   },
  { id: 'fc14', phase: 'RACE START', name: 'All personnel clear of grid',                 role: 'SAFETY',     triggerAt: 44,  type: 'auto'   },
  { id: 'fc15', phase: 'RACE START', name: 'Launch control armed',                        role: 'POWERTRAIN', triggerAt: 28,  type: 'manual' },
  { id: 'fc16', phase: 'RACE START', name: 'Start lights sequence ready',                 role: 'RC',         triggerAt: 14,  type: 'auto'   },
  { id: 'fc17', phase: 'RACE START', name: 'GO — launch on green',                        role: 'ALL',        triggerAt: 4,   type: 'auto'   },
];

window.FSAE_ARIA_TIMELINE = [
  { id: 'fa0', triggerAt: 298, type: 'system',  text: 'ARIA online. Race engineer mode active. I\'ll monitor vehicle health and coordinate pre-grid sequence through launch.' },
  { id: 'fa1', triggerAt: 245, type: 'info',    text: 'All pre-grid checks proceeding. Powertrain warm-up in progress. Confirm tyre pressures before driver ingress.', reasoning: 'Water temp climbing through 68°C, target 85°C. Estimated 50s to warm-up complete.' },
  { id: 'fa2', triggerAt: 200, type: 'info',    text: 'Engine warm-up complete. Water temp nominal. Ready for driver ingress on your call.', reasoning: 'Water 86°C, oil 3.9 bar. All powertrain metrics in green band.' },
  { id: 'fa3', triggerAt: 175, type: 'info',    text: 'Driver ingress confirmed. HANS and harness checks must be complete before T-3:30.', reasoning: 'Rulebook §A.4.7 requires full safety restraints verified before formation lap.' },
  { id: 'fa4', triggerAt: 118, type: 'warning', text: 'T-2:00. All personnel must clear the grid by T-1:00 per Race Control directive 4.2.', reasoning: 'Grid marshal coordination window closes at T-1:00. Non-compliance = DSQ.' },
  { id: 'fa5', triggerAt: 55,  type: 'success', text: 'Race Control clearance received. Grid clear. Launch authority transferred to driver. Car is ready.', reasoning: 'All 14/17 checks passed. Launch control armed. Driver has the car.' },
  { id: 'fa6', triggerAt: 8,   type: 'launch',  text: 'LIGHTS OUT. LAUNCH ON GREEN. GO GO GO.' },
];

window.FSAE_RADIO = [
  { id: 'fr1',  triggerAt: 288, from: 'MECH',       color: '#8A8FA8', text: 'Tyre pressures confirmed. 12.0 all round. Wheel torque good.' },
  { id: 'fr2',  triggerAt: 262, from: 'DAQ',        color: '#00C97A', text: 'Logging armed. 100 Hz confirmed. GPS lock 12 satellites.' },
  { id: 'fr3',  triggerAt: 210, from: 'POWERTRAIN', color: '#FF6B6B', text: 'Engine warm-up complete. Water 86°C, oil 3.9 bar. GO for driver ingress.' },
  { id: 'fr4',  triggerAt: 172, from: 'DRIVER',     color: '#00C97A', text: 'In the car. Mirrors set. Ready for harness.' },
  { id: 'fr5',  triggerAt: 156, from: 'SAFETY',     color: '#FFB300', text: 'HANS connected. Helmet nominal. Driver good to go.' },
  { id: 'fr6',  triggerAt: 138, from: 'COMMS',      color: '#B8A9FA', text: 'Radio check driver, how copy?' },
  { id: 'fr7',  triggerAt: 135, from: 'DRIVER',     color: '#00C97A', text: 'Loud and clear. Five by five.' },
  { id: 'fr8',  triggerAt:  98, from: 'DRIVER',     color: '#00C97A', text: 'Brake bias 60 front. TC map 3. Ready.' },
  { id: 'fr9',  triggerAt:  52, from: 'RC',         color: '#FF4D00', text: 'Race Control — grid clear. Formation in 30 seconds.' },
  { id: 'fr10', triggerAt:  22, from: 'DRIVER',     color: '#00C97A', text: 'Launch control armed. Standing by.' },
  { id: 'fr11', triggerAt:   6, from: 'RE',         color: '#FF4D00', text: 'Lights in 5. Execute launch. You got this.' },
];

window.FSAE_SUBSYSTEM_EXPLANATIONS = {
  POWERTRAIN:   'Engine RPM, throttle position, water temperature (target 85°C), oil pressure. Warm-up runs 65→88°C over ~100s.',
  AERO:         'Front/rear downforce estimates from pitot array, ride heights. Nominal F32/R28.5mm. Deviation signals pitch/bump.',
  SUSPENSION:   'Roll angle, damper travel, tire surface temp. FL/FR travel delta reveals setup asymmetry.',
  DAQ:          'Data logging rate (100 Hz target), CAN bus load, GPS fix, onboard storage. >85% CAN load = packet loss risk.',
  DRIVER:       'Lateral/longitudinal G, steering angle, brake pressure. Inputs validate driver technique and car balance.',
  RACE_CONTROL: 'Lap number, last lap time, best lap, fuel level. Fuel % ticks down during green-flag running.',
};
