// Radio + Checklist panel — replaces ApprovalQueue for copilot and fsae modes
const { useRef: _rcR, useEffect: _rcE } = React;

function RadioChecklistPanel({
  title,
  checklist,
  radio,
  done,
  onAck,
  phases,           // for FSAE: array of phase names
  roleFilter,       // copilot: highlight items for this role's checklistRoles
  roleColor,
  remaining,
  isComplete,
  compact,
}) {
  const logRef = _rcR(null);
  _rcE(() => { if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight; }, [radio.length]);

  const totalCk = checklist.length;
  const doneCk = done.size;

  const phaseMap = phases
    ? phases.reduce((acc, p) => { acc[p] = checklist.filter(c => c.phase === p); return acc; }, {})
    : null;

  const isOwn = (it) => roleFilter?.includes(it.role) || roleFilter?.includes('ALL') || it.role === 'ALL';

  return (
    <section className="approval" style={{ display: 'flex', flexDirection: 'column' }}>
      <div className="panel-head">
        <span className="panel-title">{title}</span>
        <span className="panel-sub">{doneCk}/{totalCk} COMPLETE</span>
      </div>

      <div className="approval__progress">
        <div className="approval__progress-fill" style={{ width: `${(doneCk / totalCk) * 100}%` }} />
        {checklist.map((c, i) => (
          <span key={c.id}
                className={`approval__tick ${done.has(c.id) ? 'tick--done' : ''}`}
                style={{ left: `${(i / Math.max(1, totalCk - 1)) * 100}%` }} />
        ))}
      </div>

      {isComplete && (
        <div className="approval__done">
          <div className="approval__done-icon">◆</div>
          <div className="approval__done-title">LAUNCH</div>
          <div className="approval__done-sub">ALL CHECKS COMPLETE</div>
        </div>
      )}

      <div className="rc-body" ref={logRef}>
        {/* ── Checklist ── */}
        <div className="rc-block">
          <div className="rc-block__head">CHECKLIST</div>

          {phaseMap ? (
            Object.entries(phaseMap).map(([phase, items]) => (
              <div key={phase} className="rc-phase">
                <div className="rc-phase__label">— {phase} —</div>
                {items.map(it => (
                  <ChecklistRow key={it.id} item={it} done={done.has(it.id)}
                                own={isOwn(it)} roleColor={roleColor}
                                onAck={() => onAck(it)} armed={remaining <= it.triggerAt && !done.has(it.id)} />
                ))}
              </div>
            ))
          ) : (
            checklist.map(it => (
              <ChecklistRow key={it.id} item={it} done={done.has(it.id)}
                            own={isOwn(it)} roleColor={roleColor}
                            onAck={() => onAck(it)} armed={remaining <= it.triggerAt && !done.has(it.id)} />
            ))
          )}
        </div>

        {/* ── Radio ── */}
        <div className="rc-block">
          <div className="rc-block__head">RADIO LOOP</div>
          {radio.length === 0
            ? <div className="rc-empty">— quiet —</div>
            : radio.slice(-40).map(r => (
              <div key={r.id} className="rc-radio">
                <span className="rc-radio__from" style={{ color: r.color }}>{r.from}</span>
                <span className="rc-radio__text">{r.text}</span>
                <span className="rc-radio__t">{window.formatCountdown(r.at)}</span>
              </div>
            ))
          }
        </div>
      </div>
    </section>
  );
}

function ChecklistRow({ item, done, own, roleColor, onAck, armed }) {
  const isManual = item.type === 'manual';
  return (
    <div className={`rc-row ${done ? 'rc-row--done' : ''} ${armed ? 'rc-row--armed' : ''} ${own ? 'rc-row--own' : ''}`}
         style={own && !done ? { borderLeft: `2px solid ${roleColor}` } : undefined}>
      <span className={`rc-check ${done ? 'rc-check--done' : ''}`}>{done ? '✓' : armed && isManual ? '◉' : '◯'}</span>
      <div className="rc-row__body">
        <div className="rc-row__name">{item.name}</div>
        <div className="rc-row__meta">
          <span className="rc-row__role" style={{ color: own ? roleColor : 'var(--grey)' }}>{item.role}</span>
          <span className="rc-row__t">{window.formatCountdown(item.triggerAt)}</span>
          <span className="rc-row__type">{item.type}</span>
        </div>
      </div>
      {!done && isManual && armed && (
        <button className="rc-ack" onClick={onAck}>ACK</button>
      )}
    </div>
  );
}

window.RadioChecklistPanel = RadioChecklistPanel;
