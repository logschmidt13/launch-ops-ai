// ARIA Bar — thin always-visible strip with ARIA's latest utterance + pulse
const { useMemo: barM } = React;

function AriaBar({ messages, remaining, isHolding, onClick }) {
  const latest = barM(() => {
    for (let i = messages.length - 1; i >= 0; i--) {
      if (messages[i].type !== 'user') return messages[i];
    }
    return null;
  }, [messages]);

  const anomaly = latest?.anomaly || latest?.type === 'warning';
  const isLaunch = latest?.type === 'launch';
  const isOk = latest?.type === 'success';

  return (
    <div className={`aria-bar ${anomaly ? 'aria-bar--warn' : ''} ${isLaunch ? 'aria-bar--launch' : ''} ${isOk ? 'aria-bar--ok' : ''}`}
         onClick={onClick}
         role={onClick ? 'button' : undefined}>
      <div className="aria-bar__left">
        <span className="aria-bar__pulse" />
        <span className="aria-bar__tag">ARIA</span>
        <span className="aria-bar__sep">·</span>
        <span className="aria-bar__state">{isHolding ? 'STANDBY' : anomaly ? 'MONITORING' : 'NOMINAL'}</span>
      </div>
      <div className="aria-bar__text">
        {latest ? `"${latest.text}"` : 'Standing by…'}
      </div>
      <div className="aria-bar__right">
        <span className="aria-bar__time">{latest ? window.formatTime(latest.timestamp) : '—'}</span>
        {onClick && <kbd className="aria-bar__kbd">⌘K</kbd>}
      </div>
    </div>
  );
}
window.AriaBar = AriaBar;
